package com.qiyouhudong.sdk;

public interface Callback {
    void next();
}
