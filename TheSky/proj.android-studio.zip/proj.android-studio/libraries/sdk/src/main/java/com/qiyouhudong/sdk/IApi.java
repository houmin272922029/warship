package com.qiyouhudong.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import org.cocos2dx.lib.Cocos2dxGLSurfaceView;
import org.cocos2dx.lib.Cocos2dxLuaJavaBridge;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * SDK API统一接口定义
 * <p/>
 * Created by linguofeng on 12/7/15.
 */
public abstract class IApi {
    protected Activity mActivity = null;

    void onApplicationCreate(Context context) {

    }

    void init(Activity activity) {
        mActivity = activity;
        onInit();
    }

    /**
     * 初始化
     */
    abstract void onInit();


    /**
     * 渠道编号
     *
     * @return 渠道编号
     */
    abstract int ChannelCode();

    /**
     * 渠道
     *
     * @return 渠道名称
     */
    abstract String Channel();

    /**
     * 显示登录界面
     *
     * @param cb Lua回调函数
     */
    abstract void Login(final int cb);

    /**
     * 显示登录界面
     *
     * @param platform 平台，比如QQ或微信
     * @param cb       Lua回调函数
     */
    void Login(final int platform, final int cb) {

    }

    /**
     * 支付
     *
     * @param amount 金额
     * @param extra  订单号
     * @param cb     Lua回调函数
     */
    abstract void Pay(final String amount, final String extra, final int cb);

    /**
     * 提交扩展数据
     *
     * @param json json对象
     */
    void submitExtendData(final JSONObject json) {

    }

    /**
     * 是否显示自定义弹窗，退出弹窗
     *
     * @return 是否显示
     */
    boolean isShowCustomDialog() {
        return false;
    }

    /**
     * 显示自定义弹窗
     *
     * @param cb 回调函数
     */
    void showCustomDialog(Callback cb) {

    }

    void onResume() {

    }

    void onPause() {

    }

    void onDestroy() {

    }

    void onStop() {
    }

    void onRestart() {
    }
    void exitgame(){}

    void onNewIntent(Intent intent) {

    }
    void onActivityResult(int requestCode, int resultCode, Intent data){}

    /**
     * 登录成功
     *
     * @param cb    lua回调函数
     * @param token 用户token
     */
    protected void onLoginSuccessWithToken(final int cb, String token) {
        this.onLoginSuccess(cb, null, null, token);
    }

    /**
     * 登录成功
     *
     * @param cb       lua回调函数
     * @param uid      用户UID
     * @param username 用户名
     * @param token    用户token
     */
    protected void onLoginSuccess(final int cb, String uid, String username, String token) {
        if (cb == 0) return;
        final JSONObject json = new JSONObject();
        try {
            json.put("status", true);
            json.put("uid", uid == null ? "" : uid);
            json.put("username", username == null ? "" : username);
            json.put("token", token);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        this.callLua(cb, json.toString());
    }

    /**
     * 支付成功
     *
     * @param cb lua回调函数
     */
    protected void onPaySuccess(final int cb) {
        final JSONObject json = new JSONObject();
        try {
            json.put("status", true);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        this.callLua(cb, json.toString());
    }

    /**
     * 调用Lua回调
     *
     * @param cb  lua函数值
     * @param str 内容
     */
    protected void callLua(final int cb, final String str) {
        Cocos2dxGLSurfaceView.getInstance().queueEvent(new Runnable() {
            @Override
            public void run() {
                Cocos2dxLuaJavaBridge.callLuaFunctionWithString(cb, str);
                Cocos2dxLuaJavaBridge.releaseLuaFunction(cb);
            }
        });
    }
}
