package com.qiyouhudong.sdk;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

import org.json.JSONObject;

public class Api {
    private static IApi iApi = null;
    private static Activity sActivity = null;

    /**
     * 创建API，会根据packageName去反射具体的API实现
     *
     * @param packageName 需要创建的Api包名
     */
    public static void createSDK(String packageName) {
        if ("null".equals(packageName) || iApi != null) return;

        try {
            Class clazz = Class.forName(packageName);
            iApi = (IApi) clazz.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void onApplicationCreate(Context context) {
        if (iApi != null)
            iApi.onApplicationCreate(context);
    }

    public static void onInit(Activity activity) {
        sActivity = activity;
        if (iApi != null) iApi.init(activity);
    }

    public static void onResume() {
        if (iApi != null) iApi.onResume();
    }

    public static void onPause() {
        if (iApi != null) iApi.onPause();
    }

    /**
     * 获取渠道编号
     *
     * @return
     */
    public static String Channel() {
        if (iApi == null) return "qiyou";
        return iApi.Channel();
    }

    /**
     * 获取渠道编号
     *
     * @return
     */
    public static int ChannelCode() {
        if (iApi == null) return 2;
        return iApi.ChannelCode();
    }
    public static void exitgame() {
        if (iApi == null);
        System.out.println("进来了");
        sActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                iApi.exitgame();
            }
        });
    }

    /**
     * 显示登录界面
     *
     * @param cb Lua回调函数
     */
    public static void Login(final int cb) {
        if (iApi != null)
            sActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    iApi.Login(cb);
                }
            });
    }

    /**
     * 显示登录界面
     *
     * @param platform QQ或微信
     * @param cb       Lua回调函数
     */
    public static void Login(final int platform, final int cb) {
        if (iApi != null)
            sActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    iApi.Login(platform, cb);
                }
            });
    }

    /**
     * 显示支付界面
     *
     * @param amount 价钱
     * @param extra  订单号
     * @param cb     Lua回调函数
     */
    public static void Pay(final String amount, final String extra, final int cb) {
        if (iApi != null)
            sActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    iApi.Pay(amount, extra, cb);
                }
            });
    }

    /**
     * 提交扩展数据
     *
     * @param json
     */
    public static void submitExtendData(final JSONObject json) {
        if (iApi != null) iApi.submitExtendData(json);
    }

    public static boolean isShowCustomDialog() {
        if (iApi != null) return iApi.isShowCustomDialog();
        return false;
    }

    public static void showCustomDialog(final Callback cb) {
        if (iApi != null)
            sActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    iApi.showCustomDialog(cb);
                }
            });
    }

    public static void showChangeUserDialog() {
        new AlertDialog.Builder(sActivity)
                .setTitle("提示")
                .setMessage("确认要切换用户吗？\n确认后将自动退出游戏，请手动启动游戏并在自动登录时选择切换用户。")
                .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        onDestroy();
                        sActivity.finish();
                        System.exit(0);
                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create()
                .show();
    }

    public static void onDestroy() {
        if (iApi != null) iApi.onDestroy();
    }


    public static void onRestart() {
        if (iApi != null)
            iApi.onRestart();
    }

    public static void onStop() {
        if (iApi != null)
            iApi.onStop();
    }

    public static void onNewIntent(Intent intent) {
        if (iApi != null)
            iApi.onNewIntent(intent);
    }
    public static void onActivityResult(int requestCode, int resultCode, Intent data){
        if (iApi != null)
            iApi.onActivityResult(requestCode, resultCode, data);
    }
}
