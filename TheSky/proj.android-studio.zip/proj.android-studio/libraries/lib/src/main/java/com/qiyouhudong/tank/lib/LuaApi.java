package com.qiyouhudong.tank.lib;

import com.qiyouhudong.sdk.Api;
import com.qiyouhudong.sdk.Callback;

import org.cocos2dx.lib.Cocos2dxHelper;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * 供Lua调的Api
 * <p/>
 * Created by linguofeng on 12/16/15.
 */
public class LuaApi {
    public static void doAction(final String jsonStr) {
        Cocos2dxHelper.getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject json = new JSONObject(jsonStr);
                    String action = json.getString("action");
                    switch (action) {
                        case "setInfo":
                            AnalyticsLua.setInfo(json);
                            break;
                        case "onEvent":
                            AnalyticsLua.onEvent(json);
                            break;
                        case "onLevel":
                            AnalyticsLua.onLevel(json);
                            break;
                        case "onCrash":
                            AnalyticsLua.onCrash(json);
                            break;
                        case "onExitGame":
                            if (Api.isShowCustomDialog()) {
                                Api.showCustomDialog(new Callback() {
                                    @Override
                                    public void next() {
                                        AnalyticsLua.onExitGame();
                                    }
                                });
                            } else {
                                AnalyticsLua.onExitGame();
                            }
                            break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static String getInfo(String key) {
        return "{\"data\": \"123abc\"}";
    }
}
