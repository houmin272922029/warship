package com.qiyouhudong.tank.lib;

import android.util.Log;

import com.qiniu.android.dns.DnsManager;
import com.qiniu.android.dns.Domain;
import com.qiniu.android.dns.IResolver;
import com.qiniu.android.dns.NetworkInfo;
import com.qiniu.android.dns.Record;
import com.qiniu.android.dns.http.DnspodEnterprise;
import com.qiniu.android.dns.local.AndroidDnsServer;
import com.qiniu.android.dns.local.Resolver;

import org.cocos2dx.lib.Cocos2dxGLSurfaceView;
import org.cocos2dx.lib.Cocos2dxLuaJavaBridge;

import java.io.IOException;
import java.net.InetAddress;

// Dnspod.lua use it
public class Dnspod {
    public static void query(final String domain, final String id, final String key, final int callback) {
        Log.i("Dnspod", "query: " + domain + " callback: " + callback);

        // 子线程请求网络
        new Thread(new Runnable() {
            public void run() {
                String ip = domain;
                DnspodEnterprise resolver = new DnspodEnterprise(id, key);
                try {
                    Record[] records = resolver.resolve(new Domain(domain), null);
                    if (records != null && records.length > 0) {
                        for (Record record : records) {
                            Log.i("Dnspod", "HTTP IP: " + record.value);
                        }
                        ip = records[0].value;
                    } else {
                        IResolver[] resolvers = new IResolver[3];
                        resolvers[0] = AndroidDnsServer.defaultResolver();
                        resolvers[1] = new Resolver(InetAddress.getByName("119.29.29.29"));
                        resolvers[2] = new Resolver(InetAddress.getByName("223.5.5.5"));
                        DnsManager dns = new DnsManager(NetworkInfo.normal, resolvers);
                        String[] ips = dns.query(domain);
                        if (ips != null && ips.length > 0) {
                            for (String ip2 : ips) {
                                Log.i("Dnspod", "DNS IP: " + ip2);
                            }
                            ip = ips[0];
                        }
                    }
                } catch (IOException e) {
                    Log.e("Dnspod", "IOException", e);
                }

                // 回调lua
                final String newip = ip;
                Cocos2dxGLSurfaceView.getInstance().queueEvent(new Runnable() {
                    @Override
                    public void run() {
                        Cocos2dxLuaJavaBridge.callLuaFunctionWithString(callback, newip);
                        Cocos2dxLuaJavaBridge.releaseLuaFunction(callback);
                    }
                });
            }
        }).start();
    }
}
