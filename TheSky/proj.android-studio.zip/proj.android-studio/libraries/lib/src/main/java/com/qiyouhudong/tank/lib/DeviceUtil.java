package com.qiyouhudong.tank.lib;

import android.content.Context;
import android.provider.Settings;
import android.telephony.TelephonyManager;

/**
 * @author xingyong@360.cn
 * @ClassName: DeviceUtil
 * @Description: 获取设备信息工具
 * <p/>
 * 所有的设备都可以返回一个 TelephonyManager.getDeviceId()
 * 所有的GSM设备 (测试设备都装载有SIM卡) 可以返回一个TelephonyManager.getSimSerialNumber()
 * 所有的CDMA 设备对于 getSimSerialNumber() 却返回一个空值！
 * 所有添加有谷歌账户的设备可以返回一个 ANDROID_ID
 * 所有的CDMA设备对于 ANDROID_ID 和 TelephonyManager.getDeviceId() 返回相同的值（只要在设置时添加了谷歌账户）
 * 目前尚未测试的：没有SIM卡的GSM设备、没有添加谷歌账户的GSM设备、处于飞行模式的设备。
 * @date 14/12/15 下午3:07
 */
public class DeviceUtil {

    /**
     * 获取设备IMEI
     * <p/>
     * 真实设备的标识，它根据不同的手机设备返回IMEI，MEID或者ESN码，但它在使用的过程中会遇 到很多问题：
     * 非手机设备： 如果只带有Wifi的设备或者音乐播放器没有通话的硬件功能的话就没有这个DEVICE_ID
     * 权限： 获取DEVICE_ID需要READ_PHONE_STATE权限，但如果我们只为了获取它，没有用到其他的通话功能，那这个权限有点大才小用
     * bug：在少数的一些手机设备上，该实现有漏洞，会返回垃圾，如:zeros或者asterisks的产品
     *
     * @return
     */
    public static String getDeviceId(Context context) {
        TelephonyManager telephonyMgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyMgr.getDeviceId();
    }


    /**
     * 获取ANDROID_ID
     * <p/>
     * ANDROID_ID是设备第一次启动时产生和存储的64bit的一个数，当设备被wipe后该数重置
     * 它在Android <=2.1 or Android >=2.3的版本是可靠、稳定的，但在2.2的版本并不是100%可靠的
     * 在主流厂商生产的设备上，有一个很经常的bug，就是每个设备都会产生相同的ANDROID_ID：9774d56d682e549c
     *
     * @return
     */
    public static String getAndroidId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    /**
     * 获取手机SIM卡的序列号
     * <p/>
     * 需要权限：READ_PHONE_STATE
     *
     * @return
     */
    public static String getSerialNumber(Context context) {
        TelephonyManager telephonyMgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyMgr.getSimSerialNumber();
    }

    /**
     * 获取设备唯一编号
     * <p/>
     * MD5(DeviceId + SerialNumber + AndroidId + UUID)
     *
     * @return
     */
    public static String getDeviceUuid(Context context) {
        return MD5Code.encode(getDeviceId(context) + getSerialNumber(context) + getAndroidId(context));
    }
}
