package com.qiyouhudong.tank.lib;

public class LuaException extends Throwable {
    public LuaException(String s) {
        super(s);
    }
}
