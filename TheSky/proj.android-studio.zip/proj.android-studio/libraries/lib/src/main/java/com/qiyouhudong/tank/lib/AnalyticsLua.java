package com.qiyouhudong.tank.lib;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.dataeye.DCAccount;
import com.dataeye.DCAgent;
import com.dataeye.DCEvent;
import com.dataeye.DCReportMode;
import com.dataeye.plugin.DCLevels;
import com.qiyouhudong.sdk.Api;
import com.qiyouhudong.sdk.Callback;
import com.umeng.analytics.MobclickAgent;
import com.umeng.analytics.game.UMGameAgent;

import org.json.JSONException;
import org.json.JSONObject;

import im.fir.sdk.FIR;

public class AnalyticsLua {
    private static Activity s_activity = null;

    public static void onApplicationCreate(Context context, String sdkPackageName) {
        Api.createSDK(sdkPackageName);
        Api.onApplicationCreate(context);
    }

    public static void onCreate(Activity activity) {
        s_activity = activity;

        Api.onInit(activity);

        UMGameAgent.init(activity);

        DCAgent.setReportMode(DCReportMode.DC_AFTER_LOGIN);

        Log.i("AnalyticsLua", "onCreate");
    }

    public static void onResume() {
        Api.onResume();
        UMGameAgent.onResume(s_activity);
        DCAgent.onResume(s_activity);
        Log.i("AnalyticsLua", "onResume");
    }

    public static void onPause() {
        Api.onPause();
        UMGameAgent.onPause(s_activity);
        DCAgent.onPause(s_activity);
        Log.i("AnalyticsLua", "onPause");
    }

    public static void doAction(final String jsonStr) {
        s_activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject json = new JSONObject(jsonStr);
                    String action = json.getString("action");
                    switch (action) {
                        case "setInfo":
                            setInfo(json);
                            break;
                        case "onEvent":
                            onEvent(json);
                            break;
                        case "onLevel":
                            onLevel(json);
                            break;
                        case "onCrash":
                            onCrash(json);
                            break;
                        case "onPay":
                            onPay(json);
                            break;
                        case "onExitGame":
                            if (Api.isShowCustomDialog()) {
                                Api.showCustomDialog(new Callback() {
                                    @Override
                                    public void next() {
                                        onExitGame();
                                    }
                                });
                            } else {
                                onExitGame();
                            }
                            break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void setInfo(JSONObject json) throws JSONException {
        Log.i("AnalyticsLua", "doAction setInfo");
        JSONObject params = json.getJSONObject("params");

        Api.submitExtendData(params);

        String id = params.getString("accountid");
        String sec = params.getString("sec");
        int level = params.getInt("level");

        UMGameAgent.onProfileSignIn(id);
        UMGameAgent.setPlayerLevel(level);

        DCAccount.login(id);
        DCAccount.setGameServer(sec);
        DCAccount.setLevel(level);

        FIR.addCustomizeValue("id", id);
        FIR.addCustomizeValue("sec", sec);
    }

    public static void onEvent(JSONObject json) throws JSONException {
        Log.i("AnalyticsLua", "doAction onEvent");
        JSONObject params = json.getJSONObject("params");

        String name = params.getString("name");

        MobclickAgent.onEvent(s_activity, name);
        DCEvent.onEvent(name);
    }

    public static void onLevel(JSONObject json) throws JSONException {
        Log.i("AnalyticsLua", "doAction onLevel");
        JSONObject params = json.getJSONObject("params");

        String name = params.getString("name");
        int status = params.getInt("status");

        UMGameAgent.startLevel(name);
        DCLevels.begin(name);
        switch (status) {
            case 0: // 关卡挑战失败
                UMGameAgent.failLevel(name);
                DCLevels.fail(name, "default");
                break;
            case 1: // 关卡挑战成功
                UMGameAgent.finishLevel(name);
                DCLevels.complete(name);
                break;
        }
    }

    public static void onCrash(JSONObject json) throws JSONException {
        Log.i("AnalyticsLua", "doAction onCrash");
        JSONObject params = json.getJSONObject("params");

        FIR.sendCrashManually(new LuaException(params.getString("message")));
    }

    public static void onPay(JSONObject json) throws JSONException {
        int cash = json.getInt("cash");
        int coin = json.getInt("coin");

        UMGameAgent.pay(cash, coin, Api.ChannelCode() + 21);
    }

    public static void onExitGame() {
        Api.onDestroy();
        DCAgent.onKillProcessOrExit();
        UMGameAgent.onKillProcess(s_activity);

        s_activity.finish();
        System.exit(0);
    }

    public static void onRestart() {
        Api.onRestart();
    }

    public static void onStop() {
        Api.onStop();
    }
    public static void onDestroy() {
        Api.onDestroy();
    }

    public static void onNewIntent(Intent intent) {
        Api.onNewIntent(intent);
    }

}
