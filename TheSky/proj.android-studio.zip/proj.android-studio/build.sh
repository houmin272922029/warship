#!/usr/bin/env bash

cd `dirname "$0"`

NAME="$1" # Develop Master ...
TYPE="$2" # Debug Release

if [[ "${TYPE}abc" == "abc" ]]; then
    TYPE="Debug"
fi

NAME=`echo ${NAME:0:1} | tr '[a-z]' '[A-Z]'`${NAME:1}
TYPE=`echo ${TYPE:0:1} | tr '[a-z]' '[A-Z]'`${TYPE:1}

ASSEMBLE="assemble${NAME}${TYPE}"

echo "Build Name:" $NAME
echo "Build Type:" $TYPE

PROJ_PATH=`pwd`
NDK_MODULE_PATH=${PROJ_PATH}/../../cocos2d-x:${PROJ_PATH}/../../cocos2d-x/cocos/:${PROJ_PATH}/../../cocos2d-x/external:${PROJ_PATH}/../../cocos2d-x/cocos/scripting

if [[ "${TYPE}" == "Release" ]]; then
    NDK_DEBUG=0
else
    NDK_DEBUG=1
fi

echo "NDK Debug: ${NDK_DEBUG}"
echo "工程: ${PROJ_PATH}"
echo " "
echo "[NDK] 开始编译C++源码"
ndk-build \
    NDK_MODULE_PATH=${NDK_MODULE_PATH} \
    NDK_TOOLCHAIN_VERSION=4.9 \
    NDK_DEBUG=${NDK_DEBUG} \
    APP_PLATFORM=android-9 \
    -C ${PROJ_PATH}/app \
    -j8
echo "[NDK] 编译C++源码完成"

echo " "
/Users/sun/Downloads/tank-qh360/assets/res/Resources/common/img
echo "[RSYNC] 开始拷贝游戏资源"
rsync \
    --verbose \
    --recursive \
    --checksum \
    --delete \
    --copy-links \
    --exclude='.DS_Store' \
    --include='res/' \
    --include='src/' \
    --include='config.json' \
    --exclude='/*' \
    ${PROJ_PATH}/../../../ \
    ${PROJ_PATH}/app/src/main/assets/

# 热更新资源
rsync \
    --verbose \
    --recursive \
    --checksum \
    --delete \
    --exclude='.DS_Store' \
    --include='pkgmanager/' \
    --exclude='/*' \
    ${PROJ_PATH}/../../../pkgmanager/ \
    ${PROJ_PATH}/app/src/main/assets/
echo "[RSYNC] 拷贝游戏资源完成"



# 编译apk
echo " "
echo "[APK] 开始打包"
echo "sh gradlew clean $ASSEMBLE"
sh gradlew clean $ASSEMBLE
echo "[APK] 打包完成"
