package com.qiyouhudong.sdk

import android.app.AlertDialog
import android.app.Application
import android.content.Context
import android.util.Log
import com.baidu.bdgame.sdk.obf.e
import com.baidu.gamesdk.*
import com.baidu.platformsdk.PayOrderInfo
import org.json.JSONObject

/**
 * Created by 林国锋 @linguofeng.com> on 1/4/16.

 * Baidu
 */
class Baidu : IApi() {

    private lateinit var mActivityAdPage: ActivityAdPage
    private lateinit var mActivityAnalytics: ActivityAnalytics
    private lateinit var notify_url: String

    override fun onApplicationCreate(context: Context) {
//        e.a(context as Application)
        BDGameSDK.initApplication(context as Application);
    }


    override fun onInit() {
        val setting = BDGameSDKSetting().apply {
            appID = 7529665;
            appKey = "WmFW1YmK1MOyGYeKQ2r9EpMf";
            domain = BDGameSDKSetting.Domain.RELEASE;
            orientation = BDGameSDKSetting.Orientation.LANDSCAPE;
        }

        BDGameSDK.init(mActivity, setting) { resultCode, resultDesc, extraData ->
            when (resultCode) {
                ResultCode.INIT_SUCCESS -> {
                    Log.d(TAG, resultDesc)
                    BDGameSDK.getAnnouncementInfo(mActivity)
                }
            }
        }

        BDGameSDK.setSuspendWindowChangeAccountListener { resultCode, resultDesc, void ->
            when (resultCode) {
                ResultCode.LOGIN_SUCCESS -> {
                    AlertDialog.Builder(mActivity).apply {
                        setTitle("提示")
                        setMessage("帐号切换成功，重启游戏后生效，确定后请重新启动游戏")
                        setNegativeButton("确定", { dialog, code ->
                            dialog.dismiss()
                            Api.onDestroy()
                            mActivity.finish()
                            System.exit(0)
                        })
                    }.show()
                }
            }
        }

        BDGameSDK.setSessionInvalidListener { resultCode, resultDesc, void ->
            if (resultCode == ResultCode.SESSION_INVALID) {
                AlertDialog.Builder(mActivity).apply {
                    setTitle("提示")
                    setMessage("帐号会话失效，请重新登录，确定后请重新启动游戏")
                    setNegativeButton("确定", { dialog, code ->
                        dialog.dismiss()
                        Api.onDestroy()
                        mActivity.finish()
                        System.exit(0)
                    })
                }.show()
            }
        }

        mActivityAdPage = ActivityAdPage(mActivity) {
            Log.d(TAG, "close")
        }

        mActivityAnalytics = ActivityAnalytics(mActivity)
    }

    override fun ChannelCode(): Int {
        return 10
    }

    override fun Channel(): String {
        return "baidu"
    }

    override fun Login(cb: Int) {
        BDGameSDK.login { resultCode, resultDesc, extraData ->
            when (resultCode) {
                ResultCode.LOGIN_SUCCESS -> {
                    BDGameSDK.showFloatView(mActivity)
                    onLoginSuccess(cb, BDGameSDK.getLoginUid(), BDGameSDK.getLoginUid(), BDGameSDK.getLoginAccessToken())
                }
            }
        }
    }

    override fun Pay(amount: String, extra: String, cb: Int) {
        val info = PayOrderInfo().apply {
            cooperatorOrderSerial = extra
            productName = "${amount}0钻石"
            totalPriceCent = amount.toLong() * 100
            extInfo = extra
        }

        BDGameSDK.pay(info, notify_url) { resultCode, resultDesc, payInfo ->
            when (resultCode) {
                ResultCode.PAY_SUCCESS, ResultCode.PAY_SUBMIT_ORDER -> {
                    onPaySuccess(cb)
                }
            }
        }
    }

    override fun submitExtendData(json: JSONObject) {
        if (json.has("notify_url"))
            notify_url = json.getString("notify_url");
    }

    override fun onResume() {
        if (BDGameSDK.isLogined())

        mActivityAdPage.onResume()
        mActivityAnalytics.onResume()
    }

    override fun onPause() {

        mActivityAdPage.onPause()
        mActivityAnalytics.onPause()
    }

    override fun onStop() {
        mActivityAdPage.onStop()
    }

    override fun onDestroy() {
        mActivityAdPage.onDestroy()
        BDGameSDK.closeFloatView(mActivity)
        BDGameSDK.destroy()
    }
    override fun exitgame(){
        println("进来了111111111")
        BDGameSDK.gameExit(mActivity, object : OnGameExitListener {

           override fun onGameExit() {
                System.exit(0)
            }

        })
    }
    companion object {
        val TAG = "Baidu"
    }
}
