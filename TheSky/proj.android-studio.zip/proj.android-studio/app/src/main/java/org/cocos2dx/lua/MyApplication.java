package org.cocos2dx.lua;

import android.app.Application;

import com.qiyouhudong.tank.BuildConfig;
import com.qiyouhudong.tank.lib.AnalyticsLua;

import im.fir.sdk.FIR;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        FIR.init(this);
        super.onCreate();
        AnalyticsLua.onApplicationCreate(this, BuildConfig.SDK_PACKAGE_NAME);
    }
}
