#include "AppDelegate.h"
#include "cocos2d.h"
#include "platform/android/jni/JniHelper.h"
#include <jni.h>
#include <android/log.h>
#include "ide-support/SimpleConfigParser.h"
#include "ide-support/CodeIDESupport.h"

#define  LOG_TAG    "main"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)

using namespace cocos2d;

void cocos_android_app_init (JNIEnv* env) {
    LOGD("cocos_android_app_init");
    AppDelegate *pAppDelegate = new AppDelegate();
}

extern "C"
{
    bool Java_org_cocos2dx_lua_AppActivity_nativeIsLandScape(JNIEnv *env, jobject thisz)
    {
        return SimpleConfigParser::getInstance()->isLanscape();
    }

	bool Java_org_cocos2dx_lua_AppActivity_nativeIsDebug(JNIEnv *env, jobject thisz)
	{
#if (COCOS2D_DEBUG > 0) && (CC_CODE_IDE_DEBUG_SUPPORT > 0)
        return true;
#else
        return false;
#endif
	}

    // 华为SDK私钥
    jstring Java_com_qiyouhudong_sdk_Huawei_privateKey(JNIEnv *env, jobject thisz)
    {
        return env->NewStringUTF("MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIgi8R2C505vaOrcPip/eY061Cfp4R9ldyLVddAgs1Bjz0j5UCURLlGUfyqnwkbSda7y5d9kRLEyOma6f/BRkXGNQ2EUPzDjpPequ3JM5Uq3+eYO5nxY5GEA4gQA1hkaMlUVg75U3YQlFb3ixceksGD5dKDXGkOpn6QAoKTGkB8JAgMBAAECgYB2O5KZBNWK42uFfl5nXmrc45jaSV+BewfrMuStK5lQWj7uq8iVSMSniYagLy6lf6dBmCdYyqZ2Fp9uFM+EkfL0FpEjKEvc5QxmuAotTJyQXufQRejJeuoTGyzAlyTYFECtm0z8V+ClbAUs6dqsYs8/PlrMnEdU7VhnE4lqMOfiuQJBAOU6KNUPc1UBbW6wJyd7ALjnLlY6Wx3RWsYiifjwoPdchqhDbxPtlIcng4i/kUgP6pGgTZWP3678pKiAHobmF/cCQQCYCWRRXJFy2u9HIaQdtzszit0nCDo4qBP1t8ljgg4/DzBJq/fVH3rV7uhKgASXtdE+LjY9syb6bIBdkSp+g8D/AkAsfY1PTSBlb1F+GlJ/JzCMstIbilgFAY1Mx4df+dRELoE0R2JXy9T4JoMxF31rLyun+CUW0kXoAME0syk5pY8hAkB1SsmZ+1A6y6zNs6ZpRnLl0LvM4QwJqaG8b41ut2dGPvGB5KnOQfsCEM4kq57fa+WBkyVFdHEdwZdGmDewYvUBAkByhyK/4PlD2obwiFy3Fy0X+BeRlgyIo6tROpYtx5yaGOOGxqa9jE8EFVf9+aJmb/mW050sD26zvzbNEeYJiKOF");
    }

    // 华为SDK支付私钥
    jstring Java_com_qiyouhudong_sdk_Huawei_payPrivateKey(JNIEnv *env, jobject thisz)
    {
        return env->NewStringUTF("MIIBVQIBADANBgkqhkiG9w0BAQEFAASCAT8wggE7AgEAAkEA8iZldTsoRHEacPdFcWZE5Grv0F3Qawu7k7oPe8odLBwJxRncghIP8R9M0/iMyTxwgLAiOrkkRvEZ61sqVrwRHwIDAQABAkADA9dfjk0CDSZ3IZ0LvGo/LdWuknx12L+NJ1PqBqo2UlzZP4VnUu5vQL27Nd2vqjh1HeG2NtA1hspijkBRFJkBAiEA/cwCz5Z2feC/TnwWrOsVrsTdUTEs+EBJB4EATA3GM4kCIQD0QIDinbLcrD3NatULTx8wX3tXSCC+vi+hDUroiKxtZwIgF7FB2esr6Jhgg40l+MKBZa1PE9NJZWtq5d5vDqqChDECIQCGYcrHY44ZvSYPk3x9SV3WhmHc5pElgIvB5wdUooWDdwIhAMKk+STB+kJs7PuSviEsPNYJX+QK3toM1JQB+PD/wTN2");
    }

    // 魅族appSecret
    jstring Java_com_qiyouhudong_sdk_Meizu_appSecret(JNIEnv *env, jobject thisz)
    {
        return env->NewStringUTF("my3nOt9EqnqxGy4NkSachJX9YQrGnx91");
    }
}

