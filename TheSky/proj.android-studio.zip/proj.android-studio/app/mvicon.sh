cd src

T=$1

mv ${T}/32.png ${T}/res/drawable-ldpi/icon.png
mv ${T}/48.png ${T}/res/drawable-mdpi/icon.png
mv ${T}/72.png ${T}/res/drawable-hdpi/icon.png
mv ${T}/96.png ${T}/res/drawable-xhdpi/icon.png
mv ${T}/144.png ${T}/res/drawable-xxhdpi/icon.png
mv ${T}/192.png ${T}/res/drawable-xxxhdpi/icon.png

# usage:
# sh mvicon.sh main
